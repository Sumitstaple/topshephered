<template>
    <div>
        <h2>Settings</h2>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad cupiditate sequi soluta suscipit tempore unde voluptates! Cupiditate doloribus enim esse et fugiat, ipsum, magni nostrum placeat, suscipit unde vitae voluptate?</p>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad cupiditate sequi soluta suscipit tempore unde voluptates! Cupiditate doloribus enim esse et fugiat, ipsum, magni nostrum placeat, suscipit unde vitae voluptate?</p>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad cupiditate sequi soluta suscipit tempore unde voluptates! Cupiditate doloribus enim esse et fugiat, ipsum, magni nostrum placeat, suscipit unde vitae voluptate?</p>
    </div>
</template>

<script>
  export default {
    name: 'Dashboard',
  };
</script>

<style scoped>

</style>